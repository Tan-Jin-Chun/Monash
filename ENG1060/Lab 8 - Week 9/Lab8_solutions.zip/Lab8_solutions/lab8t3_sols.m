% Written by Tony Vo
clear all; close all; clc;

% data
mass = [400 70 45 2 0.3 0.16];
metab = [270 82 50 4.8 1.45 0.97];

% checking if numer of terms of x and y are equal
if length(mass)~=length(metab)
    disp('error in matrix size')
end

%% part A
% Using polyfit (power law)
x = log10(mass);
y = log10(metab);
p = polyfit(x,y,1);

% calculating goodness of fit (r2)
Sr = sum((y-p(2)-(p(1).*x)).^2);
St = sum((y-mean(y)).^2);
r2 = (St-Sr)/St;

% model: metab = alpha*mass^beta
alpha = 10^(p(2));
beta = p(1);

fprintf('The non-linear equation is metabolism = %.4f*mass^%.4f\n',alpha,beta);
fprintf('The coefficient of determination, r^2, is %5.4f\n', r2);

%% part B
% plotting 
plot(mass,metab,'rd')
xlabel('mass (kg)')
ylabel('metabolism (watts)')

% Interpolating/extrapolating data
x_fit = 0:500;
y_fit = alpha*x_fit.^beta;
x_200 = 200;
y_200 =  alpha*x_200.^beta;

fprintf('200kg tiger''s metabolic rate is %.4f watts\n', y_200);

% plotting
hold on
plot(x_fit,y_fit,'b-',x_200,y_200,'kd')
legend('original data', 'interpolated/extrapolated data','Tiger')
title(sprintf('metabolism = %.4f*mass^{%.4f}',alpha,beta))
hold off


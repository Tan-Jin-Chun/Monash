function r2 = r2nonlin(f,x,y)
% [r2] = r2nonlin(f,x,y) calculates the nonlinear coeff of determination r2
% using the nonlinear function's function handle, and raw data x and y

st = sum((y-mean(y)).^2);
sr = sum((y-f(x)).^2);
r2 = (st-sr)/st;

% end

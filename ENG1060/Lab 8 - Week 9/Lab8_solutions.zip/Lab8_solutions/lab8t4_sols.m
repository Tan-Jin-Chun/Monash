% Written by: Tony Vo
clc; clear all; close all;

%% data used to design question
% x = 2*pi*rand(1,100);
% x = sort(x);
% y = sin(x) + sin(2*x) + 0.5*rand(size(x));
% plot(x,y,'ko')

%% part A
coords = importdata('xy_data.txt');
x = coords(1,:);
y = coords(2,:);
plot(x,y,'ko')
xlabel('x')
ylabel('y')
hold on


%% part B
p = polyfit(x,y,7);
x_req = 0;
y_est = polyval(p,x_req);
fprintf('For 7th polynomial degree, y=%.4f at x=0\n',y_est)

%% part C
degrees = [2,3,5,9];
xfit = linspace(-3,3.5,100);

for i=1:length(degrees)
    p = polyfit(x,y,degrees(i));
    yfit = polyval(p,xfit);
    plot(xfit,yfit)
end

legend('raw data', 'p=2', 'p=3', 'p=5', 'p=9')




% Written by Tony Vo
clear all; close all; clc;

% data
T = 5:5:45;
S = [1.95 1.7 1.55 1.4 1.3 1.15 1.05 1 0.95];

% checking if numer of terms of x and y are equal
if length(T)~=length(S)
    disp('error in matrix size')
end

%% part B
% Using polyfit (power law)
x = log10(T);
y = log10(S);
[a0,a1,r2] = linreg(x,y);

% model: S = alpha*T^beta
alpha = 10^(a0);
beta = a1;

fprintf('The non-linear equation is S = %.4f*T^%.4f\n',alpha,beta);
fprintf('The coefficient of determination, r^2, is %5.4f\n', r2);

%% part C+D
% plotting 
plot(T,S,'bo')
xlabel('Temperature (\circC))')
ylabel('Solubility of O2 in water)')

% Interpolating/extrapolating data
x_fit = 0:60;
y_fit = @(x) alpha*x.^beta;
x_50 = 50;
y_50 =  y_fit(x_50);

fprintf('Solubility of O2 in water at 50 degrees is %.4f\n', y_50);

% plotting
hold on
plot(x_fit,y_fit(x_fit),'k-',x_50,y_50,'rd')
legend('original data', 'interpolated/extrapolated data','50\circC')
title(sprintf('S = %.4f*T^{%.4f}',alpha,beta))
hold off

%r2 nonlinear
r2_nonlinear = r2nonlin(y_fit,T,S);
fprintf('r2 nonlinear = %f\n', r2_nonlinear)

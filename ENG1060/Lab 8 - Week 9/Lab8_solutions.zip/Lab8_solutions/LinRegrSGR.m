function [F, V, a0, a1, r2] = LinRegrSGR(m, a, order)
% [vm, ks, r2] = sg_lin(S, v) 
% Written by: ???, ID: ???
% Last modified: ???
% Performs linear regression on the linear x and y data set 
%
% INPUTS:
%  - S: linear independent data set 
%  - v: linear dependent data set 
% OUTPUT:
%  - vm: constant in v = vm * S^2/(ks + S^2)
%  - ks: constant in v = vm * S^2/(ks + S^2)
%  - r2: coefficient of determination

% linearising data
x = 1./m.^order;
y = 1./a;

% determine a0 and a1 coefficients using polyfit 
p = polyfit(x,y,1);
a0 = p(2);
a1 = p(1);

% non-linear coefficients
F = 1/a0;
V = (a1*F)^(1/order);

% calculating r2
st = sum((y-mean(y)).^2);
sr = sum((y-a0-a1*x).^2);
r2 = (st-sr)/st;
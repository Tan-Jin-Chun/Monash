% Written by: Tony Vo
clc; clear all; close all;

%% part A
%raww data
m=[1.3 1.8 3 4.5 6 8 9];
a=[0.07 0.13 0.22 0.275 0.335 0.35 0.36];
order = 2;
[F, V, a0, afit, r2] = LinRegrSGR(m, a, order);

%% part b
fprintf('F = %f\n',F);
fprintf('V = %f\n',V);
fprintf('a0 = %f\n',a0);
fprintf('a1 = %f\n',afit);
fprintf('r2 = %f\n',r2);

%% part c
mfit = 1:0.1:10;
afit = @(mfit) (F.*mfit.^order) ./ ((V)^order + mfit.^order); %second order graph
plot(m, a, 'rs', mfit, afit(mfit), 'b--');
legend('data','second order','location','northwest')
title('second order model Using LinRegrSGR vs Data')
xlabel('mass')
ylabel('accelaration')
% Written by Tony Vo
clear all; close all; clc;

%all numbers
all_nums = importdata('numbers.txt');

%lucky numbers
lucky_nums = [2, 220, 389, 725, 768, 241, 36, 953, 531, 161];

%lucky number occurence
count = zeros(size(lucky_nums));

for i=1:length(lucky_nums)
        count(i) = sum(lucky_nums(i) == all_nums);
end

%max count of lucky numbers
total_count = sum(count);
[max_count, id] = max(count);
luckiest_num = lucky_nums(id);

%print statement
fprintf('Lucky numbers appear %d times and number %d appears most frequently\n',...
    total_count, luckiest_num)


%Written by Tony Vo
clear all; close all; clc;

%variables
x = 0:0.001:50;
f = x.^(1./x);

%using user-defined max function
[max_f, index] = mymax(f);

%plotting
plot(x,f,'r',x(index),max_f,'bo')
xlabel('x')
ylabel('f(x)')
legend('f(x)','max')

%using MATLAB max function
[max_f2, index2] = max(f);

%fprintf
fprintf('The maximum value is %f and the index is %d\n',max_f, index)

%checking (optional)
[max_value, row, col] = mymax2(f);
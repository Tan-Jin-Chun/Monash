function [max_value, row, col] = mymax2(x)
%Written by Tony Vo
%My own max function for 2D matrices
%returns the maximum value and the corresponding row and column

%kick starting variables
[m,n] = size(x);

%assuming max value
max_value = x(1,1);

%for loop checking each element
for i=1:m
    for j=1:n
        if max_value < x(i,j)
            max_value = x(i,j);
            row = i;
            col = j;
        end
    end
end
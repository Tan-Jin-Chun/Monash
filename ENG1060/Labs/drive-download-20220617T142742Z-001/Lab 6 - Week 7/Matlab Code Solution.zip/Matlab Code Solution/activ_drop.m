function [ydrop] = activ_drop(fhandle,x)
%% Implement activation function on input x  
y = fhandle(x);
%% Calculate ydrop by assigning 0 value to elements of y which are less than 0.5 
ydrop = zeros(size(y));
for i=1:length(y) 
    if y(i)<0.5
       ydrop(i)=0;
    else 
       ydrop(i)=y(i);
    end
end

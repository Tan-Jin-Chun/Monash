function [max_value, index] = mymax(x)
%Written by Tony Vo
%My own max function for 1D vectors
%returns the maximum value and the corresponding index

%kick starting variables
index = 1;
max_value = x(index);

%for loop checking each element
for i=2:length(x)
    if max_value < x(i)
        max_value = x(i);
        index = i;
    end
end
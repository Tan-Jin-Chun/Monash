% Written by Zhi Ng, Modified by Soon Foo Chong
% plotting with several function handles
close all; clear all; clc
%% function handles
f1 = @(x) 1./(1+exp(-x));
f2 = @(x) (exp(x)-exp(-x))./(exp(x)+exp(-x));
f3 = @(x) log(1+exp(x));
f4 = @(x) exp(-x.^2);

fset = {f1;f2;f3;f4}; %function handles
%% 
x = -3:0.01:3;

%% for loop to go through each function handle
for j = 1:4
    [ydrop] = activ_drop(fset{j},x);   
    subplot(2,2,j) %ydrop subplot 
    plot(x,ydrop,'b')
    axis equal
    xlabel('Input')
    ylabel('Output')
    title(char(fset{j}))
    f_end(j) = ydrop(end);
end
sum_f_end = sum(f_end)

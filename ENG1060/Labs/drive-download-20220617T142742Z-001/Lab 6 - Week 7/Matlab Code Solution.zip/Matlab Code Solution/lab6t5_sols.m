% Written by Tony Vo
% growth of a pollutant
clear all; close all; clc;

%% pollutant information
alpha = 10:25;
beta = 5:30;
nmax = 50;
n = 1:nmax;
p_interior = @(alpha, beta, n) alpha^-n + n*abs(cos(beta)).^(sin(alpha));
p = zeros(length(alpha),length(beta));

%% for loop to calculate the combinations of alpha, beta and n
for a = 1:length(alpha) % all the possibilities of alpha
    for b = 1:length(beta) % all the possibilities of beta
        for i = 1:length(n) % calculating p
            p(a,b) = p(a,b) + p_interior(alpha(a),beta(b),n(i));
        end
    end
end

%% finding the alpha and beta that corresponds to the lowest growth
% using min() function
% [~,col_ind] = min(min(p));
% [~,row_ind] = min(p(:,col_ind));

% using find() function
%alternative code in finding the minimum growth
[row_ind, col_ind] = find(p == min(min(p)));
alpha_min_p = alpha(row_ind);
beta_min_p = beta(col_ind);

% fprintf minimum p information
fprintf('Minimum p=%f when alpha=%.0f and beta=%.0f\n',min(min(p)),alpha_min_p,beta_min_p)

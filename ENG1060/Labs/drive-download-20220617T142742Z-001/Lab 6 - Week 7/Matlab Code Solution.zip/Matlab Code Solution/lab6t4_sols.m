% Written by Tony Vo
% Square wave function
clear all; close all; clc;
tic

%% part A
%variables 
T = 1;
t_plot = -T:0.0001:T; 
f_plot = zeros(size(t_plot));

%plotting square wave
for i = 1:length(t_plot)
    if t_plot(i) >= -1 && t_plot(i) < 0
        f_plot(i) = -1;
    else
        f_plot(i) = 1;
    end
end

plot(t_plot,f_plot,'r-')
xlabel('t')
ylabel('function value')

%% part B
k_max = input('Input maximum value of k: ');

% Fourier series
Fsum_plot = 0;
for k = 0:k_max
    Fsum_plot = Fsum_plot + (1/(2*k+1))*sin(((2*k+1)*pi*t_plot)/T);
end
Fsum_plot = 4/pi*Fsum_plot;

%plotting
hold on
plot(t_plot,Fsum_plot,'b-')
title(sprintf('Terms used = %d, Max k = %d',k_max+1, k_max))
legend('square wave','Fourier series','location','northwest')

%To find a noninteger value, use a tolerance value based on your data
ind = find(abs(t_plot-0.1) < 0.000001);
Fs_01 = Fsum_plot(ind);

toc
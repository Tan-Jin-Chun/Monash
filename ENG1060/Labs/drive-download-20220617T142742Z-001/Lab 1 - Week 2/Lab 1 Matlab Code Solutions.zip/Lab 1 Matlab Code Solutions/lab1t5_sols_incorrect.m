% Written by: Tony Vo
clear all; close all; clc

tao/Q = 4*mu/pi*R^3
Q = 4.58*10e-6
R = 43
mu = 0.3



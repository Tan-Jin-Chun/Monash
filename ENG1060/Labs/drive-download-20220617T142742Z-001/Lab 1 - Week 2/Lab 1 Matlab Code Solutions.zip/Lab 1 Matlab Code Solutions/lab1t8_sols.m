% Written by: Tony Vo
clear all; close all; clc

spacing = 1;
base = 3:spacing:7 ;
height = 10:spacing:16 ;

%% Using matrix multiplication
Area = 0.5 * base' * height 

function [t, v] = VPiecewise(t_start, t_end)
% [t, v] = VPiecewise(t_start, t_end)
% Written by: Tony Vo, ID: 123456789
% Last modified: ???
% Piecewise velocity profiles
%
% INPUTS:
%  - t_start = starting time value
%  - t_end = ending time value
%
% OUTPUTS:
%  - t = time vector
%  - v = velocity vector

t = t_start:0.01:t_end;

% Computing piecewise function for each value of t
v = zeros(size(t));
for i = 1:length(t)
    v(i) = 0;
    if t(i) > 30
        v(i) = 1520*exp(-0.1 * (t(i)-30));
    elseif t(i) > 20
        v(i) = 50*t(i) + 2*(t(i) - 20)^2.5;
    elseif t(i) > 10
        v(i) = 1100 - 5*t(i);
    elseif t(i) > 0
        v(i) = 11*t(i)^2 - 5*t(i);
    else
        v(i) = 0;
    end
end


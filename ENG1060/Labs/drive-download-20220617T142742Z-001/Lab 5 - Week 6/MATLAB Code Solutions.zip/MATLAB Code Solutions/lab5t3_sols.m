% Written by Tony Vo
% Evaluating roots of a quadratic equations
clear all; close all; clc;

%fprintf message
fprintf('Quadratic Program - What are the quadratic coefficients?\n');

%inputs for coefficients
a = input('a = ');

while a==0
    disp('A non-zero value of a must be entered')
    a = input('Re enter value a ... ');
end

b = input('b = ');
c = input('c = ');

%calling function
[x1, x2, discriminant] = my_quadratic(a,b,c);

%fprintf
if discriminant > 0
    fprintf('For quadratic coefficients a=%2.2f, b=%2.2f and c=%2.2f\n', a,b,c)
    fprintf('A pair of non-equal real valued roots exists and are %5.3f and %5.3f\n',x1,x2)
    
elseif discriminant ==0
    fprintf('For quadratic coefficients a=%2.2f, b=%2.2f and c=%2.2f\n', a,b,c)
    fprintf('A pair of equal real valued roots exists and are %5.3f and %5.3f\n',x1,x2)
    
elseif discriminant < 0
    fprintf('For quadratic coefficients a=%2.2f, b=%2.2f and c=%2.2f\n', a,b,c)
    fprintf('A pair of non-equal complex valued roots exists and are x1=%5.3f + %5.3fi and x2=%5.3f - %5.3fi\n',real(x1), abs(imag(x1)), real(x2), abs(imag(x2)))
end
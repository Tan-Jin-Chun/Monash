% Written by: Soon Foo Chong
clear all; close all; clc;

%% options
option1 = fprintf('He\n');
option2 = fprintf('H2\n');
option3 = fprintf('O2\n');
option4 = fprintf('CL2\n');
option5 = fprintf('CO2\n');
option = input ('Please enter the type of gas based on options shown above: ','s');

%% check if the option is valid
while (strcmp(option,'He')~=1) && (strcmp(option,'H2')~=1) && (strcmp(option,'O2')~=1) && (strcmp(option,'CL2')~=1) && (strcmp(option,'CO2')~=1)
    option = input ('Please enter the type of gas based on options shown above: ','s');
end

%% user input for T and V
T = input('Please enter the absolute temperature T (K): ');
% checking if temperature is negative
while T <= 0
    T = input('Please enter the absolute temperature T (K): ');
end

V = input('Please enter the volume V (L/mol): ');
% checking if volume is negative
while V <= 0
    V = input('Please enter the volume V (L/mol): ');
end

%% pressure calculation
switch option
    case 'He'
        a = 0.0341;
        b = 0.0237;
    case 'H2'
        a = 0.244;
        b = 0.0266;
    case 'O2'
        a = 1.36;
        b = 0.0318;
    case 'CL2'
        a = 6.49;
        b = 0.0562;
    case 'CO2'
        a = 3.59;
        b = 0.0427;
end
%% Calculate pressure
R = 0.08206;
P = R*T/(V-b)-a/V^2;

% displaying answer
fprintf('\nPressure of %s is %.4fatm\n',option, P)
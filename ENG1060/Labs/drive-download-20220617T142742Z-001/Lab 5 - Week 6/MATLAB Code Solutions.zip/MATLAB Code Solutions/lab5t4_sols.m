% Written by Tony Vo
clear all; close all; clc;

%defining the time limits
t_start=-5;
t_end=80;

%using the function VPiecewise
[t, v] = VPiecewise(t_start, t_end);

%plotting the results
plot(t,v)
xlabel('t')
ylabel('v(t)')
title('velocity profile')

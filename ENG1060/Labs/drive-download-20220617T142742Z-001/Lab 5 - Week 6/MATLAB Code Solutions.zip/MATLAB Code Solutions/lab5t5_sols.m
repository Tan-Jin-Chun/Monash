% Written by Tony Vo
% Using own factor
clear all; close all; clc;


%% part A - Fibonacci sequence for loop
% variables
a = 10;
b = 13;
n = 10;

% preallocation
fib_seq = zeros(1,n);
fib_seq([1,2]) = [a,b];

% Fibonacci sequence
for i=3:n
    fib_seq(i) = fib_seq(i-1) + fib_seq(i-2);
end

% displaying result
fprintf('Fibonacci sequence with starting numbers [%d, %d] is\n %s\n', ...
    a,b,num2str(fib_seq))

%% part B - Fibonacci sequence while loop
% variables
precision = 1e-5;
golden_ratio = (1+sqrt(5))/2;
fib_seq = [a,b];

i = 1;
fib_ratio(i) = fib_seq(i+1)/fib_seq(i);
error = abs(golden_ratio - fib_ratio(i));

% Fibonacci sequence and ratio
while error > precision
    i = i+1;
    fib_seq(i+1) = fib_seq(i) + fib_seq(i-1);
    fib_ratio(i) = fib_seq(i+1)/fib_seq(i) ;
    error = abs(golden_ratio - fib_ratio(i));   
end

% plotting
hold on;
plot(1:length(fib_ratio), fib_ratio, '-bx')
plot(1:length(fib_ratio), golden_ratio*ones(size(fib_ratio)), '--')
legend('Fibonacci ratio','Golden ratio')
xlabel('Ratio pair')
ylabel('Fibonacci ratio')
title('Golden ratio convergence')
hold off;

% Printing the number of terms
fprintf('\n%d Fibonacci numbers needed to achieve absolute error less than %e\n', ...
    i+1,precision)
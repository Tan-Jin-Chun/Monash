% Written by: Tony Vo
% Deflection of a beam
clear all; close all; clc;

%% variables
L = 600; %length of beam (cm)
E = 50000; %modulus of elasticity (kN/cm^2)
I = 30000; %moment of inertia (cm^4)
w0 = 2.5; %distributed load 2.5 (kN/cm)

% deflection equation
y = @(x) w0/(120*E*I*L)*(-x.^5 + 2*L^2*x.^3 - L^4*x);
dydx = @(x) w0/(120*E*I*L)*(-5*x.^4 + 6*L^2*x.^2 - L^4);
dy2dx2 = @(x) w0/(120*E*I*L)*(-20*x.^3 + 12*L^2*x);

% Plotting
x = 0:0.01:L;
plot(x,y(x),'k-',x,dydx(x),'b-')
xlabel('x (cm)')
ylabel('y (cm)')
title('Deflection of a beam')
grid on

%% solving for maximum deflection 
xi = 250;
precision = 1e-4;
[root, iter] = newraph(dydx, dy2dx2, xi, precision);

%plotting
hold on
plot(root,y(root),'r*')
legend('deflection', 'deflection gradient', 'max deflection','location','se')
hold off

% fprintf statement
fprintf('The maximum deflection of %.2fcm occurs at %.2fcm\n',...
    y(root),root)
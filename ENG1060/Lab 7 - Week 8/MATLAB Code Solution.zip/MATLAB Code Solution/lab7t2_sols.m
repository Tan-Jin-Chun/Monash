% Written by Tony, modified by Soon Foo Chong
% Throwing angles
clear all; close all; clc;

% Variables given
g = 9.81;
x = 35; % distance of catcher
v0 = 20; % Initial velocity
y0 = 2; % initial thrower's elevation
y_target = 1; % catcher's elevation
precision = 0.001;

% defining function (note the substraction of y_target at the end)
y = @(theta) tand(theta)*x-(g*(x^2)./(2*v0^2*cosd(theta).^2))+y0-y_target;

% defining angles to plot
angles = linspace(0,60,100);
 
% plotting the function of f(theta) vs theta
plot(angles,y(angles))
xlabel('theta')
ylabel('y(theta)')

% setting initial guesses (based on graph)
xi = 15; %15
xi_1 = 60; %60

% Caltulating roots and number of iteration
[root, iter] = secant(y, xi, xi_1, precision);

%plotting
hold on
plot(root,y(root),'kd')
legend('y(theta)','root')
hold off

%fprintf
fprintf('The initial throw angle is %5.3f degrees and no. of iterations taken to find the solution is %d\n',root,iter)
% Written by: Tony
% This program uses Newton Raphson to determine the depth of water in a tank
clear all; close all; clc;

% Variables given
R = 3; % radius of tank
V = 30; % Volume of water
precision = 1e-4;

% defining function (note the substraction of V at the end)
f = @(h) ((pi()*h.^2).*(((3*R) - h) / 3))- V;
df = @(h) ((2*pi*R*h)-(pi*(h.^2)));

% defining heights to plot 
h = linspace(0,10,100);
 
% plotting the function of f(theta) vs theta
plot(h,f(h))
xlabel('height h')
ylabel('f(h)')
title(sprintf('f(h) = %sh^2(3R-h)/3 - %d','\pi',V))

% Getting user inputs
xi = input('Enter initial guess xi: ');

% Caltulating roots and number of iteration
[root, iter] = newraph(f, df, xi, precision);

% plotting roots
hold on
plot(root,f(root),'b^')
legend('f(h)','root')
hold off

%fprintf
fprintf(['The depth of water required to fill 30m^3 of water is %5.3fm,\n' ...
    'and it took %d iterations to solve using the Newton-Raphson method\n'], ...
    root,iter)
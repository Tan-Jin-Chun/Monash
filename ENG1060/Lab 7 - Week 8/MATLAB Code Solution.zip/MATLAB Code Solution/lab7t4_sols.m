% Written by: Tony Vo
% This program uses false position method to determine the food
% concentration at which yeast growth is maximum
clear all; close all; clc;

% Define parameters required to solve the problem 
f = @(c) 2*c./(4+0.8*c+c.^2+0.2*c.^3);
df = @(c) 10*(20-5*c.^2-2*c.^3)./(c+5).^2./(c.^2+4).^2;
precision = 1e-4;
xu = 5;
xl = 0;

% Use false position function to solve the problem
[rt, iter] = falseposition(df, xl, xu, precision);

% Plot graph to verify the result
cc = linspace(0,10);
gcc = f(cc);
dgcc = df(cc);
plot(cc, gcc, cc, dgcc, [rt rt], [-0.1 0.6])
title('Groath rate of yeast')
xlabel('c [mg/L]')
ylabel('g(c) / g''(c)')
legend('g(c)', 'g''(c)', 'Max Growth')

% Print result in Command Window
fprintf('The growth rate is maximum when the concentration is %.4f mg/L.\n',rt);
fprintf('It took %d iterations to converge to this value.\n',iter);
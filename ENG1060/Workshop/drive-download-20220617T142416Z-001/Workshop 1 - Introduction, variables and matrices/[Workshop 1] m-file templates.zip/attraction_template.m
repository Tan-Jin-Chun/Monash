% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

%variables

%calculating the gravitational attraction



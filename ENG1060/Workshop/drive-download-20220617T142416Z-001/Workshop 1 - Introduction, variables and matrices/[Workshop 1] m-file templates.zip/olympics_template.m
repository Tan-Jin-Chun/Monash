% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

medals = [14 14 11; 14 10 7; 11 8 10; 9 8 6; 8 6 6; ...
    7 6 1; 5 8 4; 5 6 4; 5 4 6; 5 3 6]

%extract 1st row


%extract last row


%extract 1st column (gold)


%extract last column (bronze)


%sum of medals for each country


%append summed metals onto medals matrix



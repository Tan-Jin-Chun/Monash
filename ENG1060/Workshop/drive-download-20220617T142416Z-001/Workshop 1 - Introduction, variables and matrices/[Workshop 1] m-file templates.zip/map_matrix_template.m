% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

%create matrices C and D from matrices A and B
A = [13 27 41 55 69]; 
B = [20 40 80 60 10];



%matrices pre-defined
key = [0 9 0 8 1; 0 6 0 4 7; 0 2 0 3 5; 0 0 0 0 0; 0 0 0 0 0]

%extracting sub matrix from key


% sum of squares

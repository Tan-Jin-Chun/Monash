% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

% spread out lamps in 20 metre intervals along 400 metres

 
% spread out 23 lamps over 400m


% costs if each lamp costs $75 to install


% option a cost if 1st lamp cost $150
% each successive one costs $6 less
% i.e. final lamp (21st) is $30

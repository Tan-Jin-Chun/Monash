% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

% variables
z = -5:5; %-5:1:5; vector

f = 1/sqrt(2*pi)*exp(-z.^2/2);

f_largest = max(f)
f_average = mean(f)

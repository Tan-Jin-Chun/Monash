% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

% spread out lamps in 20 metre intervals along 400 metres
x_a = 0:20:400;
 
% spread out 23 lamps over 400m
x_b = linspace(0,400,23);

% costs if each lamp costs $75 to install
num_a = length(x_a);
num_b = length(x_b);

cost_a = 75 * num_a
cost_b = 75 * num_b

% option a cost if 1st lamp cost $150
% each successive one costs $6 less
% i.e. final lamp (21st) is $30
cost_rev_a = 150:-6:30;
total_cost_rev_a = sum(cost_rev_a)

cost_rev_a2 = linspace(150,30,21);
total_cost_rev_a2 = sum(cost_rev_a2)

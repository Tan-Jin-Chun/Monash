% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

%creating the vector
v = linspace(1.6, 13.7, 10);

%calculating the magnitude
v_squared = v.^2;
v_mag = sqrt(sum(v_squared))

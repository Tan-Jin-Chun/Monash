% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

%variables
mass_tom = 74.5;
mass_sally = 56.7;
G = 6.67e-11;%6.67*10^-11
d = 9.8;

%calculating the gravitational attraction
Fg = G*mass_tom*mass_sally/d^2


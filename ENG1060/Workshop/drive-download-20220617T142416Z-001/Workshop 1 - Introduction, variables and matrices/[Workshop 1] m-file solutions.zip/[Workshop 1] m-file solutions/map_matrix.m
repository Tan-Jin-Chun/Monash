% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;

%create matrices C and D from matrices A and B
A = [13 27 41 55 69]; 
B = [20 40 80 60 10];

C = [B;A]
D = [A(1) A(4) A(5);B(1) B(3) B(5)] %D = [A(1) A(4:5);B(1:2:5)]

C1 = C(2,2) %row, column

D1 = D(1,3) %row, column

%matrices pre-defined
key = [0 9 0 8 1; 0 6 0 4 7; 0 2 0 3 5; 0 0 0 0 0; 0 0 0 0 0]

%extracting sub matrix from key
subm = key([1:3],[2,4:5])

% sum of squares
subm_sum_square = sum(sum(subm.^2))
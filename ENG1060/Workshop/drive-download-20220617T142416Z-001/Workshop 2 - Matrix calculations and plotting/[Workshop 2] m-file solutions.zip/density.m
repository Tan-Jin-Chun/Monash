% Written by: Tony Vo, ID: 12345678
% Last modified: ???
clear all; close all; clc;
%% part a
%temperatures in Fahrenheit
Tf = 32:3.6:82.4;

%temperatures in Celsius
Tc = 5/9*(Tf-32);

%calculating density, rho
rho = -8.5016e-6*Tc.^2 + 6.5622e-5*Tc + 0.99987;

%plotting
plot(Tc,rho,'r-','linewidth',2)
xlabel('Temperature in Celcius (\circC)')
ylabel('Density in g/cm^3')
title('Freshwater density')

%% part b
%finding the maximum and corresponding address
[max_density, index] = max(rho)
corr_Tc = Tc(index)

%plotting maximum point
hold on
plot(corr_Tc,max_density,'k^')
hold off

% Written by: Tony Vo, ID: 12345678
% Last modified: ???
clear all; close all; clc;
%% part a
%material variables
L=35;
E=200e9;
I=348e-6;
w=5.3e3;

%x and y variables
x1 = 0:0.1:(1/3*L);
y1 = -w*x1/(24*L*E*I).*(L*x1.^3 - 10/9*L^2*x1.^2 + 25/81*L^4);
x2 = (1/3*L):0.1:L;
y2 = -w*L/(216*E*I).*(2*x2.^3 - 6*L*x2.^2 + 37/9*L^2*x2-1/9*L^3);

%plotting and labelling
plot(x1,y1,'c--',x2,y2,'r--')
xlabel('x')
ylabel('y')
title('beam deflection')

%% part b
%finding the minimum
[max_y, index] = min(y2)
corr_x = x2(index)

%plotting the minimum point
hold on
plot(corr_x, max_y,'b*')
hold off
text(corr_x, max_y, '(max deflection)')
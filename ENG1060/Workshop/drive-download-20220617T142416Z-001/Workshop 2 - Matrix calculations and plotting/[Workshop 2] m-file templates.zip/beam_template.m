% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;
%% part a
%material variables
L=35;
E=200e9;
I=348e-6;
w=5.3e3;

%x and y variables
x1 = 
y1 = -w*x1/(24*L*E*I).*(L*x1.^3 - 10/9*L^2*x1.^2 + 25/81*L^4);
x2 = 
y2 = -w*L/(216*E*I).*(2*x2.^3 - 6*L*x2.^2 + 37/9*L^2*x2-1/9*L^3);

%plotting and labelling


%% part b
%finding the minimum


%plotting the minimum point

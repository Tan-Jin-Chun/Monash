% Written by: ???, ID: 12345678
% Last modified: ???
clear all; close all; clc;
%% part a
% variables
radius = 
volume = 800;

% height rearranged from volume equation


% costs rearranged from surface area
cost_cylin = 2*pi*radius.*height*300;
cost_hemi = 2*pi*(radius.^2)*400;
total_cost=cost_cylin+cost_hemi;

% Plot graph
plot(  )
title('Graph of water tank radius vs cost')
xlabel('Radius')
ylabel('Cost')
grid on


%% part b
%finding minimum point


%plotting minimum point

% Written by: Tony Vo, ID: 12345678
% Last modified: ???
clear all; clc; close all;

% variables
p= ...
pref=2*10^-5;
SPL= ...

%subplot panel 1
subplot(2,1,1)
plot(p,SPL)
xlabel('pressure (Pa)')
ylabel('SPL (dB)')
grid on

%subplot panel 2
subplot(2,1,2)
loglog(p,SPL)
xlabel('pressure (Pa)')
ylabel('SPL (dB)')
grid on

%marking SPL of p0=200
p0 = 200;
SPL_band= 20*log10(p0/pref);
subplot(2,1,2)
hold on 



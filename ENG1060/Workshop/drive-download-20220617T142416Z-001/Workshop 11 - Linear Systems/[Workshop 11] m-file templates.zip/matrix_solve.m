%Written by: ???, ID: ???
%Created: ???
%Matrix solve
clear all; close all; clc;
 
%% set A (non-zero pivot)
A = [1 4 5; 5 6 7; 8 9 8];
b = [2 3 6]';
 
xa =            %inversion
xb =            %left division
xc =            %naive Gauss
M = [xa xb xc]';
 
fprintf('Equation set A\n')
fprintf('%10s %10s %12s\n','inverse','left div.','naive Guass')
fprintf('%10f %10f %12f\n',M)
 
%% set B (zero pivot)
A = [1 4 5; 0 0 7; 8 9 9];
b = [2 3 6]';
 
xa =            %inversion
xb =            %left division
xc =            %naive Gauss
M = [xa xb xc]';

fprintf('\nEquation set B\n')
fprintf('%10s %10s %12s\n','inverse','left div.','naive Guass')
fprintf('%10f %10f %12f\n',M)
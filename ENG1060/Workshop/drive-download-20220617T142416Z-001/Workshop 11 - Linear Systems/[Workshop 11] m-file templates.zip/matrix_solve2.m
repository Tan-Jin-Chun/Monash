%Written by: ???, ID: ???
%Created: ???
%Matrix solve II
clear all; close all; clc;

%% set A
A = [2 2 0 1; 0 0 1 2; 0 2 1 0.5; 0 -1 3 1.5];
b = [10 7 9 13]';

xa = inv(A)*b;
xb = A\b;
xc = naive_gauss(A,b);
xd = gauss(A,b);
M = [xa xb xc xd]';

fprintf('Equation set A\n')
fprintf('%10s %10s %12s %12s\n','inverse','left div.','naive Guass', 'Guass pivot')
fprintf('%10f %10f %12f %12f\n',M)



%% set B
A = [1 4 5; 0 0 7; 8 9 9];
b = [2 3 6]';
xa = inv(A)*b;
xb = A\b;
xc = naive_gauss(A,b);
xd = gauss(A,b);
M = [xa xb xc xd]';

fprintf('\n Equation set B\n')
fprintf('%10s %10s %12s %12s\n','inverse','left div.','naive Guass', 'Guass pivot')
fprintf('%10f %10f %12f %12f\n',M)
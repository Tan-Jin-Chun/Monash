function x = naive_gauss(A,b)
% x = naive_gauss(A,b)
% Written by: ???, ID: ???
% Last modified: ???
% uses naive Gaussian elimination to solve matrix equation
%
% INPUTS:
%  - A = square matrix of coefficients
%  - b = column vector of solutions
% OUTPUTS:
%  - x = column vector of unknowns

% Input Validation
[m,n] = size(A);
if m~=n
    error('Matrix A must be square')
end

%preallocating x
x = zeros(n,1);

%Augmented matrix
Aug = [A b];

%% forward elimination


%% back substitution



%Written by: ???, ID: ???
%Created: ???
%object 2
clear all; close all; clc;

%inputs

v0 = 1;
vspan = [5 6];
h = 0.5;


%euler's method
[te,ve] = euler(dvdt,vspan,v0,h);

%heun's method
[th,vh] = heun(dvdt,vspan,v0,h);

%midpoint method
[tm,vm] = midpoint(dvdt,vspan,v0,h);

%% ode45
% ???
% 
% %plotting
% plot(te,ve,'mo-', th,vh,'bo-',tm,vm,'ro-')
% hold on
% plot(tode45, vode45, 'k-')
% xlabel('t')
% ylabel('v')
% legend('Euler', 'Heun', 'Midpoint', 'ode45', 'location', 'sw')
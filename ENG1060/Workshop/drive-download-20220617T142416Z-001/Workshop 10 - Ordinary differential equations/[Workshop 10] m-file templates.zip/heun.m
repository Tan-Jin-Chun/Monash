function [t,y] = heun(dydt,tspan,y0,h)
% [t,y] = heun(dydt,tspan,y0,h):
% Written by: ???, ID: ???
% Last modified: ???
% uses Heun's method to solve an ODE
%
% INPUTS:
%  - dydt = function handle of the ODE, f(t,y)
%  - tspan = [<initial value>, <final value>] of independent variable
%  - y0 = initial value of dependent variable
%  - h = step size
% OUTPUTS:
%  - t = vector of independent variable
%  - y = vector of solution for dependent variable

%% copy euler's method as a starting point

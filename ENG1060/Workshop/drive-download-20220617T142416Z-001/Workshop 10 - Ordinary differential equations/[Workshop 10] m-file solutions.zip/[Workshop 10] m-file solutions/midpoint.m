function [t,y] = midpoint(dydt,tspan,y0,h)
% [t,y] = midpoint(dydt,tspan,y0,h):
% Written by: ???, ID: ???
% Last modified: ???
% uses midpoint method to solve an ODE
%
% INPUTS:
%  - dydt = function handle of the ODE, f(t,y)
%  - tspan = [<initial value>, <final value>] of independent variable
%  - y0 = initial value of dependent variable
%  - h = step size
% OUTPUTS:
%  - t = vector of independent variable
%  - y = vector of solution for dependent variable

%% copy euler's method as a starting point

% error checking for tspan
if ~(tspan(2)>tspan(1))
    error('upper limit must be greater than lower')
end

% Create t as a column vector
t = (tspan(1):h:tspan(2))'; %column vector
n = length(t); %# pts

% if necessary, add an additional t so that range goes up to tspan(2)
if t(n)<tspan(2)
    t(n+1) = tspan(2);
    n = n+1;
end

%preallocate y using the size of t column vector
y = y0*ones(size(t));
% Implement Euler's method
for i=1:n-1
    h = t(i+1) - t(i);
    thalf = t(i) + h/2;
    yhalf = y(i) + h/2*dydt(t(i),y(i));
    y(i+1) = y(i) + h*dydt(thalf,yhalf);
end
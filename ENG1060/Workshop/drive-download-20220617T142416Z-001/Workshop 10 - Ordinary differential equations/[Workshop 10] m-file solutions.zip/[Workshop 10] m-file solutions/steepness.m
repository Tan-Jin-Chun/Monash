%Written by: ???, ID: ???
%Created: ???
%Testing Euler's method
clear all; close all; clc;

%inputs

y0 = 2;
% xspan = [0 1];
xspan = [0 1.25];
h = 0.5;
dydx = @(x,y) x - y.^2;

%function call
[x,y] = euler(dydx,xspan,y0,h);

%plotting
plot(x,y,'bo-')
xlabel('x')
ylabel('y')

%printing table of values
fprintf('%10s %10s\n', 'x','y')
fprintf('%10f %10f\n', [x';y'])
fprintf('\n')
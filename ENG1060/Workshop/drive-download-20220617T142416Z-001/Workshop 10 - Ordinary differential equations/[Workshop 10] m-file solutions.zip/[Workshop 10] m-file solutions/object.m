%Written by: ???, ID: ???
%Created: ???
%Object
clear all; close all; clc;

%inputs

v0 = 1;
vspan = [0 1]; %tspan

dvdt = @(t,v) t-v;

%% h = 0.7
h = 0.7;
[ta,va] = midpoint(dvdt,vspan,v0,h);

%% h = 0.5
h = 0.5;
[tb,vb] = midpoint(dvdt,vspan,v0,h);

%% h = 0.1
h = 0.1;
[tc,vc] = midpoint(dvdt,vspan,v0,h);

%% h = 0.05
h = 0.05;
[td,vd] = midpoint(dvdt,vspan,v0,h);

% plotting
hold on
plot(ta,va,'bo-',tb,vb,'ro-',tc,vc,'go-',td,vd,'ko-')
xlabel('t')
ylabel('v')
legend('h=0.7', 'h=0.5', 'h=0.1', 'h=0.05')

% Written by: Lai Kuan Tham 
% Modified by: ENG1060 Team

clear all; close all; clc
%% Part A
% Definition of variables
g = 9.81;    %gravity
rho = 1000;  %density
ht = 12;     %height of tank
rt = 2;      %cross-sectional radius at ht

% Setup all equations
r = @(h) rt/ht*(ht-h); %no dot
F = @(h) g*rho*pi*(r(h).^2);
W = @(h) h.*F(h);

% Plot
h = 0:0.01:ht;
plot(h,W(h));%plot(h,h.*F(h))
xlabel('Height of water (m)')
ylabel('Force exerted (N)')

%% Part B
% Work done calculation using integral()
a = 0;
b = ht;
Wint = integral(W,a,b);
fprintf('Total work required is %.3fN\n',Wint)

%% Part C
err_threshold = 0.01;
err = 100;
n=1;

% calculating percentage error between Simp's 1/3 and integral()
while (err >= err_threshold)
    n = n + 2;
    Wsim = comp_simp13(W,a,b,n);
    err = abs((Wint - Wsim)/Wint)*100;
end

% fprintfpr statements
fprintf(['%.2e%% error or less achieved with %d points for composite' ...
    ' Simpson''s 1/3 rule\n'],err_threshold,n);
fprintf('Error is 0%%. Simpson''s 1/3 rule is exact for cubic polynomials.\n')
% Written by: Tony Vo
clear all; close all; clc;

% raw data
t = [0 1 5.5 10 12 14 16 18 20 24];
c = [1 1.5 2.3 2.1 4 5 5.5 5 3 1.2];
Q = @(t) 20 + 10*sin((2*pi/24)*(t-10));

Qc = Q(t).*c;
Qvals = Q(t);

%% part A
%plot
subplot(2,1,1);
plot(t,Qc,'bo-')
xlabel('t')
ylabel('Q(t)*c(t)')
title('Q(t)*c(t) against t')

subplot(2,1,2);
plot(t,Q(t),'rs-')
xlabel('t')
ylabel('Q(t)')
title('Q(t) against t')

%% part B
%Q(t)*c(t) integration
trap1a = comp_trap_vector(t(1:2),Qc(1:2));
simp13a1 = comp_simp13_vector(t(2:4),Qc(2:4));
simp13a2 = comp_simp13_vector(t(4:6),Qc(4:6));
simp38a = simp38_vector(t(6:9),Qc(6:9));
trap3a = comp_trap_vector(t(9:10),Qc(9:10));

Qc_int = trap1a+simp13a1+simp13a2+simp38a+trap3a;

%Q(t) integration
trap1b = comp_trap_vector(t(1:2),Qvals(1:2));
simp13b1 = comp_simp13_vector(t(2:4),Qvals(2:4));
simp13b2 = comp_simp13_vector(t(4:6),Qvals(4:6));
simp38b = simp38_vector(t(6:9),Qvals(6:9));
trap3b = comp_trap_vector(t(9:10),Qvals(9:10));

Q_int = trap1b+simp13b1+simp13b2+simp38b+trap3b;

%average concentration
cbar = Qc_int/Q_int;
fprintf('The flow-weighted average concentration after 24 hours is %f\n', cbar)

%% part c
[max_Qc, index] = max(Qc);
fprintf('The maximum Q(t)c(t) value is %d and occurs at t=%d\n',max_Qc, t(index))
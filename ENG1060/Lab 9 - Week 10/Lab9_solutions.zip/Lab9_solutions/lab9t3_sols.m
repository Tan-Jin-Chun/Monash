% Written by: Tony Vo
clear all; close all; clc;

% raw data
T = 50000;
m0 = 2000;
r = 0.8;
g = 9.81;
b = 40;
t0 = 0;

m = @(t) m0*(1-r*t/b);
accel = @(t) (T-m(t)*g)./m(t);

%% plotting acceleration
t_plot = linspace(t0,b);
plot(t_plot,accel(t_plot),'b-')
xlabel('time (s)')
ylabel('acceleration (ms^{-2})')


%% velocity calculation
n = 99;

% trapzoidal rule
vtrap = comp_trap(accel,t0,b,n);

% simpson's 1/3 rule
vsimp = comp_simp13(accel,t0,b,n);

% integral function
vint = integral(accel,t0,b);

fprintf('Trapezoidal: Velocity of rocket at burnout is %.2f m/s\n',vtrap)
fprintf('Simpson''s 1/3: Velocity of rocket at burnout is %.2f m/s\n',vsimp)
fprintf('MATLAB integral: Velocity of rocket at burnout is %.2f m/s\n',vint)

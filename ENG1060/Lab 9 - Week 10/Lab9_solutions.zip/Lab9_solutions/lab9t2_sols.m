% Written by: Tony Vo
clear all; close all; clc;

f = @(x) 1-x-4*x.^3+2*x.^5;
a = -2;
b = 4;

%% part A: analytical 
%by hand or matlab built in matlab function
Ia = integral(f,a,b)

%% part B: 1 segment trap
n = 2; 
Ib = comp_trap(f,a,b,n)

%% part C: 4 segments trap
n = 5; %no. of segment = n-1
Ic = comp_trap(f,a,b,n)

%% part D: 2 segment simp13
n=3;
Id = comp_simp13(f,a,b,n)

%% part E: 6 segment simp13
n=7;
Ie = comp_simp13(f,a,b,n)

%% part F: 3 segment simp38 %no of segment is multiple of 3
n=4;
If = simp38(f,a,b)

function I = comp_trap_vector(x,y)
% I = comp_trap_vector(f,a,b,n)
% Written by: ???, ID: ???
% Last modified: ???
% Performs composite trapezoidal rule
%
% INPUTS:
%  - f: function handle of equation 
%  - a: starting integral limit
%  - b: ending integral limit
%  - n: number of points 
% OUTPUT:
%  - I: integral value

h = x(2)-x(1);

%Evaluating integral
I = h/2*(y(1) + 2*sum(y(2:end-1)) + y(end));
%  Created by Yogen
% Uses Naive Gaussian elimination to solve a set of linear equations

% Task 3(b)

% Defining resistance values
R23=30; R25=10; R35=7; R34=8; R45=15; R12=35; R56=5;

A=[1, -1, -1, 0, 0, 0, 0; 0, 1, 0, -1, -1, 0, 0; 0, 0, 1, 0, 1, 1, -1; 0, 0, 0, 1, 0, -1, 0; 0, R23, -R25, 0, R35, 0, 0; 0, 0, 0, R34, -R35, R45, 0; R12, 0, R25, 0, 0, 0, R56];
b=[0; 0; 0; 0; 0; 0; 140];

[m, n] = size(A);

% Non-square A, exit with error()
if m ~= n
   error('A needs to be square!'); 
end

% b is not a column vector, exit
[bm, bn] = size(b);
if bn ~= 1
    error('b must be a column vector!');
end

% A and b sizes must agree
if m ~= bm
    error('A and b size mismatch!');
end

Aug = [A b];
nb = n+1;       % Column index of b values in Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Forward Elimination    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Looping through all pivot elements 
% Aug(1,1), Aug(2,2) ... etc
% So, Aug(p,p) is the current pivot element
for p = 1:n-1
    % Looping through rows r below current pivot
    % factor is the normalization factor
    % p:nb in the column index avoids subtracting
    % zero values needlessly
    for r = p+1:n
        factor = Aug(r,p) / Aug(p,p);
        Aug(r,p:nb) = Aug(r,p:nb) - factor*Aug(p,p:nb);
    end
end

% Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Backward Substitution   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-allocating x vector
x = zeros(size(b));

%defining current

% Calculating last x value
x(n) = Aug(n,nb) / Aug(n, n);
 
% Again, Aug(p,p) is the pivot
% Moving through x values backwards
for p = n-1:-1:1
    x(p) = (Aug(p, nb) - Aug(p, p+1:n)*x(p+1:n) ) / Aug(p,p);
end

 fprintf('i56 = %5.4f \n', x(7))
 fprintf('i45 = %5.4f \n', x(6))
 fprintf('i35 = %5.4f \n', x(5))
 fprintf('i34 = %5.4f \n', x(4))
 fprintf('i25 = %5.4f \n', x(3))
 fprintf('i23 = %5.4f \n', x(2))
 fprintf('i12 = %5.4f \n', x(1))
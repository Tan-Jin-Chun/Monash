% Created by Yogen
% 
% Task 5(c)

clc;
clear all;
format long;
% Task 1
AT1 = [0 -3 7; 1 2 -1; 5 -2 0];
Cond_T1 = cond(AT1);

% Task 2
Q15=3; Q55=2; Q54=2; Q01=5; Q12=3; Q25=1; Q24=1; Q44=11; Q03=8; Q31=1; Q23=1; Q34=8;
C01=10; C03=20;

AT2 = [(Q15+Q12), 0, -Q31, 0, 0; -Q12, (Q25+Q23+Q24), 0, 0, 0; 0, -Q23, (Q34+Q31), 0, 0; 0, -Q24, -Q34, Q44, -Q54; -Q15, -Q25, 0, 0, (Q55+Q54)];
Cond_T2 = cond(AT2);

% Task 3
R23=30; R25=10; R35=7; R34=8; R45=15; R12=35; R56=5;

AT3=[1, -1, -1, 0, 0, 0, 0; 0, 1, 0, -1, -1, 0, 0; 0, 0, 1, 0, 1, 1, -1; 0, 0, 0, 1, 0, -1, 0; 0, R23, -R25, 0, R35, 0, 0; 0, 0, 0, R34, -R35, R45, 0; R12, 0, R25, 0, 0, 0, R56];
Cond_T3 = cond(AT3);

% Task 4
AT4 = [1.6e9, 8e6, 4e4, 200, 1; 3.90625e9, 1.5625e7, 6.25e4, 250, 1; 8.1e9, 2.7e7, 9e4, 300, 1; 2.56e10, 6.4e7, 16e4, 400, 1; 6.25e10, 1.25e8, 25e4, 500, 1];
Cond_T4 = cond(AT4);

% Task 5a)
AT5a=[1, 2, 3; 4, 5, 6; 7, 8, 9];
Cond_T5a = cond(AT5a);

% Task 5bi
AT5bi=[4.498, 3.1; 1.598, 1.1];
Cond_T5bi = cond(AT5bi);

% Task 5bii
AT5bii=[4.50, 3.1; 1.60, 1.1];
Cond_T5bii = cond(AT5bii);

fprintf('Condition for matrix for Task 1 is: %5.3f \n',Cond_T1)
fprintf('Condition for matrix for Task 2 is: %5.3f \n',Cond_T2)
fprintf('Condition for matrix for Task 3 is: %5.3f \n',Cond_T3)
fprintf('Condition for matrix for Task 4 is: %5.3e \n',Cond_T4)
fprintf('Condition for matrix for Task 5a is: %5.3e \n',Cond_T5a)
fprintf('Condition for matrix for Task 5bi is: %5.3f \n',Cond_T5bi)
fprintf('Condition for matrix for Task 5bii is: %5.3f \n',Cond_T5bii)
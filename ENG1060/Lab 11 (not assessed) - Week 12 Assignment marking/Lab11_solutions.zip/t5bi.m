% Created by Yogen
% Uses Naive Gaussian elimination to solve a set of linear equations

% Task 5(b)(i)

clc;
clear all;
format long;

A=[4.498, 3.1; 1.598, 1.1];
b = [19.249;6.843];

[m, n] = size(A);

% Non-square A, exit with error()
if m ~= n
   error('A needs to be square!'); 
end

% b is not a column vector, exit
[bm, bn] = size(b);
if bn ~= 1
    error('b must be a column vector!');
end

% A and b sizes must agree
if m ~= bm
    error('A and b size mismatch!');
end

Aug = [A b];
nb = n+1;       % Column index of b values in Aug


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Forward Elimination    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Looping through all pivot elements 
% Aug(1,1), Aug(2,2) ... etc
% So, Aug(p,p) is the current pivot element
for p = 1:n-1
    % Looping through rows r below current pivot
    % factor is the normalization factor
    % p:nb in the column index avoids subtracting
    % zero values needlessly
    
   for r = p+1:n
        factor = Aug(r,p) / Aug(p,p);
        Aug(r,p:nb) = Aug(r,p:nb) - factor*Aug(p,p:nb);
    end
end

% Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Backward Substitution   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-allocating x vector
x = zeros(size(b));

% Calculating last x value
x(n) = Aug(n,nb) / Aug(n, n);
 fprintf('y = %5.4f \n', x(n))
% Again, Aug(p,p) is the pivot
% Moving through x values backwards
for p = n-1:-1:1
    x(p) = (Aug(p, nb) - Aug(p, p+1:n)*x(p+1:n) ) / Aug(p,p);
    fprintf('x = %5.4f \n', x(p))
end


% Written by Yogen
% Uses Naive Gaussian elimination to solve a set of linear equations

% Task 2(b)

clc;
clear all;

% Defining parameters given

Q15=3; Q55=2; Q54=2; Q01=5; Q12=3; Q25=1; Q24=1; Q44=11; Q03=8; Q31=1; Q23=1; Q34=8;
C01=10; C03=20;

A = [(Q15+Q12), 0, -Q31, 0, 0; -Q12, (Q25+Q23+Q24), 0, 0, 0; 0, -Q23, (Q34+Q31), 0, 0; 0, -Q24, -Q34, Q44, -Q54; -Q15, -Q25, 0, 0, (Q55+Q54)];
b = [(Q01*C01); 0; (Q03*C03); 0; 0];

[m, n] = size(A);

% Non-square A, exit with error()
if m ~= n
   error('A needs to be square!'); 
end

% b is not a column vector, exit
[bm, bn] = size(b);
if bn ~= 1
    error('b must be a column vector!');
end

% A and b sizes must agree
if m ~= bm
    error('A and b size mismatch!');
end

Aug = [A b];
nb = n+1;       % Column index of b values in Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Forward Elimination    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Looping through all pivot elements 
% Aug(1,1), Aug(2,2) ... etc
% So, Aug(p,p) is the current pivot element
for p = 1:n-1
    % Looping through rows r below current pivot
    % factor is the normalization factor
    % p:nb in the column index avoids subtracting
    % zero values needlessly
    for r = p+1:n
        factor = Aug(r,p) / Aug(p,p);
        Aug(r,p:nb) = Aug(r,p:nb) - factor*Aug(p,p:nb);
    end
end

% Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Backward Substitution   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-allocating x vector
x = zeros(size(b));

% Calculating last x value
x(n) = Aug(n,nb) / Aug(n, n);
 fprintf('C(%d) = %6.4f \n',n, x(n))
% Again, Aug(p,p) is the pivot
% Moving through x values backwards
for p = n-1:-1:1
    x(p) = (Aug(p, nb) - Aug(p, p+1:n)*x(p+1:n) ) / Aug(p,p);
    fprintf('C(%d) = %6.4f \n',p, x(p))
end

 

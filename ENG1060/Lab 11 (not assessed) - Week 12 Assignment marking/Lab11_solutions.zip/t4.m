% Created by Yogen
% Uses Naive Gaussian elimination to solve a set of linear equations

% Task 4(b)

clc;
clear all;
format long;

A = [1.6e9, 8e6, 4e4, 200, 1; 3.90625e9, 1.5625e7, 6.25e4, 250, 1; 8.1e9, 2.7e7, 9e4, 300, 1; 2.56e10, 6.4e7, 16e4, 400, 1; 6.25e10, 1.25e8, 25e4, 500, 1];
b = [0.746; 0.675; 0.616; 0.525; 0.457];

[m, n] = size(A);

% Non-square A, exit with error()
if m ~= n
   error('A needs to be square!'); 
end

% b is not a column vector, exit
[bm, bn] = size(b);
if bn ~= 1
    error('b must be a column vector!');
end

% A and b sizes must agree
if m ~= bm
    error('A and b size mismatch!');
end

Aug = [A b];
nb = n+1;       % Column index of b values in Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Forward Elimination    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Looping through all pivot elements 
% Aug(1,1), Aug(2,2) ... etc
% So, Aug(p,p) is the current pivot element
for p = 1:n-1
    % Looping through rows r below current pivot
    % factor is the normalization factor
    % p:nb in the column index avoids subtracting
    % zero values needlessly
    for r = p+1:n
        factor = Aug(r,p) / Aug(p,p);
        Aug(r,p:nb) = Aug(r,p:nb) - factor*Aug(p,p:nb);
    end
end

% Aug

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Backward Substitution   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pre-allocating x vector
x = zeros(size(b));

% Calculating last x value
x(n) = Aug(n,nb) / Aug(n, n);
 fprintf('p(%d) = %5.4e \n',n, x(n))
% Again, Aug(p,p) is the pivot
% Moving through x values backwards
for p = n-1:-1:1
    x(p) = (Aug(p, nb) - Aug(p, p+1:n)*x(p+1:n) ) / Aug(p,p);
    fprintf('p(%d) = %5.4e \n',p, x(p))
end

